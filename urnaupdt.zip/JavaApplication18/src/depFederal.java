package urna;

import javax.swing.JOptionPane;

public class depFederal {
	private  String[] depFederal=new String[5] ;
	private int[] num=new int[5];
	private int[] qVotos=new int[5];
	private int branco;
	private int numBranco;
	private int nulo;
	private int numNulo;
	private String relatorio_local;
	
	//Método construtor
	public depFederal() {
		
		depFederal[0]="";
		depFederal[1]="";
		depFederal[2]="";
		depFederal[3]="";
		depFederal[4]="";
		
		relatorio_local="";
		numNulo=0;
		numBranco=1;
		nulo=0;
		branco=0;
		
		for(int i=0;i<5;i++) {
			num[i]=1100+i;
		}
		
		for(int j=0;j<5;j++) {
			qVotos[j]=0;
		}
	}
	
	public String[] getDepFederal() {
		return depFederal;
	}

	public int[] getNum() {
		return qVotos;
	}
	
	
	//Valida o voto do eleitor!
	public void validacao(int voto) {
		//para o testar se for nulo
		boolean anulado=true;
		
		//confirma voto e atualiza a quantidade de voto do candidato em questão!
		for(int i=0;i<5;i++) {
			if(voto==num[i]) {
				qVotos[i]++;
				JOptionPane.showMessageDialog(null,"Confirmado","Validação",1);
				anulado=false;
			}
			
		}
		
		//confirma voto branco e atualiza número de votos brancos!
		if(voto==numBranco) {
			branco++;
			JOptionPane.showMessageDialog(null,"Confirmado","Validação",1);
			anulado=false;
		}
		
		//voto será anulado e atualiza o numéro de votos anulados!
		if(anulado==true) {
			JOptionPane.showMessageDialog(null,"Confirmado","Validação",1);
			nulo++;
		}
	
	}
	
		// método para imprimir relatório da classe
		public String imprimirRela(){
			/* A variável "relatorioLocao" recebe os dados do candidatos e quantos votos receberam*/
			relatorio_local+="\nDeputado Federal\n\n";
		 for(int i=0;i<5;i++){
			relatorio_local+="Candidato: "+depFederal[i]+" Número de votos:"+qVotos[i]+"\n";
			}
		//A variável relatorioLocao recebe as quantidades de votos nulos e brancos
		
			relatorio_local+="Votos Nulos:"+nulo+"\nVotos Brancos:"+branco+"\n";

		 return relatorio_local;
		}
}