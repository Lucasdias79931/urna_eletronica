/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JOptionPane;
/**
 *
 * @author Lucas
 */
public class voto {
    public static void main(String[] args) {
        votacao candidato = new votacao();
        
        String conta=JOptionPane.showInputDialog(null,"digite a conta","conta",1);
        String senha= JOptionPane.showInputDialog(null,"digite a Senha","Senha",1);
        
        if((conta.equals("lucas"))&&(senha.equals("dias"))){
            candidato.setVisible(true);
        }
    }
}
